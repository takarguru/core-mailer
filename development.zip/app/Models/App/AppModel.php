<?php

namespace App\Models\App;

use App\Models\Core\BaseModel;

class AppModel extends BaseModel
{
    //
}
