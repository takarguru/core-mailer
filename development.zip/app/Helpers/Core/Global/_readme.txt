The files in this directory that have the word 'Helper' in them are autoloaded by HelperServiceProvider so they are available as global functions.

If you do not want a particular helper file loaded globally, place them outside of the Helpers/Global directory.