<?php


namespace App\Hooks\User;


use App\Hooks\HookContract;

class BeforeUserInvited extends HookContract
{

    public function handle()
    {
        //
    }

}
