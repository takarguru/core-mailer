<?php


namespace App\Hooks\Table;


use App\Hooks\HookContract;

class CustomTableCreated extends HookContract
{

    public function handle()
    {

    }
}
