<?php


namespace App\Hooks\Table;


use App\Helpers\Core\Traits\InstanceCreator;
use App\Hooks\HookContract;

class BeforeCustomTableSaved extends HookContract
{
    use InstanceCreator;

    public function handle()
    {

    }
}